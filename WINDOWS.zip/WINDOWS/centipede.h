class CentipedeGame
{
public:
	int score;
	int Play(void);
	
};